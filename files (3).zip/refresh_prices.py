#!/usr/bin/env python3
"""
refresh_prices.py
─────────────────────────────────────────────────────────────────────
BuildCalc Pro — Monthly automatic price refresh.

This script asks Claude AI (with web search) to find current US
market prices for each construction trade, then updates a prices.json
file that the React app reads.

USAGE:
  python3 refresh_prices.py

CRON SETUP (runs 1st of every month at 4am):
  crontab -e
  Add: 0 4 1 * * cd /var/www/buildcalc && /usr/bin/python3 refresh_prices.py >> refresh.log 2>&1

REQUIREMENTS:
  pip install anthropic
  export ANTHROPIC_API_KEY=sk-ant-...

OUTPUT:
  prices.json — read by the React app on startup
  prices_backup_YYYY-MM-DD.json — backup of previous version
  refresh.log — execution log
"""

import os
import json
import sys
import smtplib
from datetime import datetime
from pathlib import Path
from email.mime.text import MIMEText

try:
    from anthropic import Anthropic
except ImportError:
    print("ERROR: Install anthropic SDK first: pip install anthropic")
    sys.exit(1)


# ═════════════════════════════════════════════════════════════════
# CONFIG
# ═════════════════════════════════════════════════════════════════

API_KEY = os.environ.get("ANTHROPIC_API_KEY")
if not API_KEY:
    print("ERROR: Set ANTHROPIC_API_KEY environment variable")
    sys.exit(1)

# Where to write the prices file (React app reads this)
PRICES_FILE = Path(__file__).parent / "prices.json"
BACKUP_DIR = Path(__file__).parent / "price_backups"
BACKUP_DIR.mkdir(exist_ok=True)

# Email notifications (optional — set to None to disable)
NOTIFY_EMAIL = os.environ.get("NOTIFY_EMAIL")  # gptradingclub@gmail.com
SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER")
SMTP_PASS = os.environ.get("SMTP_PASS")

# Trades to refresh — must match keys in your React TRADES object
TRADES = [
    "roofing", "flooring", "drywall", "painting", "concrete",
    "framing", "plumbing", "electrical", "hvac", "siding",
    "trim", "cabinets",
]

# Base region for prices (multipliers in React applied per-region)
BASE_REGION = "Midwest USA (national average)"


# ═════════════════════════════════════════════════════════════════
# PRICE SCHEMA
# ═════════════════════════════════════════════════════════════════
# This must match the structure your calc() function expects.
# Each trade has materialRates and laborRates dicts keyed by option name.

SCHEMA_EXAMPLE = """
{
  "updated": "2026-05-12",
  "source": "Live market scan via Claude AI",
  "baseRegion": "Midwest USA (national average)",
  "roofing": {
    "materialRates": {
      "Asphalt Shingles (3-tab)": 95,
      "Architectural Shingles": 140,
      "Metal Roofing": 380,
      "Tile": 450,
      "Flat/TPO": 210
    },
    "laborRates": {
      "Asphalt Shingles (3-tab)": 60,
      "Architectural Shingles": 75,
      "Metal Roofing": 180,
      "Tile": 220,
      "Flat/TPO": 130
    }
  },
  "flooring": { ... },
  ...
}
"""


# ═════════════════════════════════════════════════════════════════
# CORE LOGIC
# ═════════════════════════════════════════════════════════════════

client = Anthropic(api_key=API_KEY)


def fetch_trade_prices(trade: str) -> dict:
    """Ask Claude to search the web for current prices for one trade."""

    prompt = f"""Search the web for CURRENT 2026 US construction market prices for: {trade}

Region baseline: {BASE_REGION}

I need PER-SQUARE (or per appropriate unit) prices for:
1. Materials only (cost per unit)
2. Labor only (cost per unit, contractor rates)

Search reputable sources: HomeAdvisor, Angi (Angies List), Fixr, Forbes Home, supplier sites (Home Depot Pro, Lowes Pro, ABC Supply).

Return ONLY a JSON object in this exact format (no markdown fences, no extra text):

{{
  "materialRates": {{ "option name": price_in_dollars, ... }},
  "laborRates": {{ "option name": price_in_dollars, ... }}
}}

The "option name" must EXACTLY match what's in my app's spec dropdowns. For {trade}, use these options:
"""

    # Trade-specific option names (must match React TRADES specs)
    trade_options = {
        "roofing": ["Asphalt Shingles (3-tab)", "Architectural Shingles", "Metal Roofing", "Tile", "Flat/TPO"],
        "flooring": ["Hardwood", "LVP / Luxury Vinyl", "Tile (12x12)", "Tile (24x24)", "Laminate", "Carpet"],
        "drywall": ["1/2\" Standard", "5/8\" Fire Rated", "1/4\" Flexible"],
        "painting": ["1 Coat", "2 Coats", "3 Coats"],
        "concrete": ["4\" Standard", "6\" Heavy Duty", "8\" Extra Heavy"],
        "framing": ["Interior Walls", "Exterior Walls", "Addition/New Build"],
        "plumbing": ["Bathroom Remodel", "Kitchen Remodel", "New Construction", "Pipe Replacement", "Water Heater"],
        "electrical": ["Panel Upgrade", "New Circuit Addition", "Full Rewire", "Remodel", "EV Charger"],
        "hvac": ["Central AC + Furnace", "Mini Split (1 zone)", "Mini Split (multi-zone)", "Heat Pump", "Ductwork only"],
        "siding": ["Vinyl Siding (standard)", "Vinyl Siding (insulated)", "Fiber Cement (HardiePlank)", "Wood Clapboard / Cedar", "Stucco", "Brick Veneer"],
        "trim": ["Finger-jointed pine (paint grade)", "Clear pine / poplar", "MDF trim", "PVC / cellular PVC (exterior)", "Oak / hardwood"],
        "cabinets": ["Stock (IKEA, Home Depot)", "Semi-custom (RTA)", "Custom shop-built", "Refacing existing boxes"],
    }

    prompt += "\n".join(f"- {o}" for o in trade_options.get(trade, []))
    prompt += "\n\nUse the SAME pricing units the React app uses (per square for roofing, per sqft for flooring/siding, per fixture for plumbing, etc.)."

    print(f"  → Searching for {trade}...", end="", flush=True)

    response = client.messages.create(
        model="claude-sonnet-4-5",  # Cheaper than Opus, good enough for this
        max_tokens=2000,
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
        messages=[{"role": "user", "content": prompt}],
    )

    # Extract JSON from response
    text_parts = [b.text for b in response.content if hasattr(b, "text") and b.type == "text"]
    full_text = "\n".join(text_parts)

    # Strip markdown code fences if present
    cleaned = full_text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
    cleaned = cleaned.strip()

    try:
        data = json.loads(cleaned)
        print(f" ✓ ({len(data.get('materialRates', {}))} materials, {len(data.get('laborRates', {}))} labor)")
        return data
    except json.JSONDecodeError as e:
        print(f" ✗ JSON parse error: {e}")
        print(f"    Raw output: {cleaned[:300]}")
        return None


def load_existing_prices() -> dict:
    """Load current prices.json (for diff comparison)."""
    if PRICES_FILE.exists():
        return json.loads(PRICES_FILE.read_text())
    return {}


def backup_existing():
    """Save a backup of the current prices file before overwriting."""
    if PRICES_FILE.exists():
        backup = BACKUP_DIR / f"prices_{datetime.now().strftime('%Y-%m-%d')}.json"
        backup.write_text(PRICES_FILE.read_text())
        print(f"  ✓ Backup: {backup.name}")


def compute_diff(old: dict, new: dict) -> list[str]:
    """Return human-readable list of meaningful price changes."""
    changes = []
    for trade in TRADES:
        if trade not in old or trade not in new:
            continue
        for rate_type in ["materialRates", "laborRates"]:
            old_rates = old.get(trade, {}).get(rate_type, {})
            new_rates = new.get(trade, {}).get(rate_type, {})
            for option, new_price in new_rates.items():
                old_price = old_rates.get(option)
                if old_price is None:
                    changes.append(f"  NEW  {trade}/{rate_type}/{option}: ${new_price}")
                elif abs(new_price - old_price) / old_price > 0.03:  # >3% change
                    pct = (new_price - old_price) / old_price * 100
                    arrow = "↑" if pct > 0 else "↓"
                    changes.append(
                        f"  {arrow}  {trade}/{rate_type}/{option}: "
                        f"${old_price} → ${new_price} ({pct:+.1f}%)"
                    )
    return changes


def send_email_notification(changes: list[str]):
    """Email the owner with what changed."""
    if not (NOTIFY_EMAIL and SMTP_USER and SMTP_PASS):
        return

    body = f"""BuildCalc Pro — Monthly Price Refresh Report
Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}

{len(changes)} significant price changes detected (>3%):

""" + "\n".join(changes[:50]) + (f"\n\n... and {len(changes)-50} more" if len(changes) > 50 else "")

    msg = MIMEText(body)
    msg["Subject"] = f"BuildCalc prices refreshed — {len(changes)} changes"
    msg["From"] = SMTP_USER
    msg["To"] = NOTIFY_EMAIL

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as s:
            s.starttls()
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
        print(f"  ✓ Notification sent to {NOTIFY_EMAIL}")
    except Exception as e:
        print(f"  ✗ Email failed: {e}")


# ═════════════════════════════════════════════════════════════════
# MAIN
# ═════════════════════════════════════════════════════════════════

def main():
    print(f"\n{'═' * 60}")
    print(f"  BuildCalc Pro — Price Refresh — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'═' * 60}\n")

    backup_existing()
    old_prices = load_existing_prices()

    new_prices = {
        "updated": datetime.now().strftime("%B %d, %Y"),
        "source": "Live market scan via Claude AI",
        "baseRegion": BASE_REGION,
    }

    failures = []
    for trade in TRADES:
        result = fetch_trade_prices(trade)
        if result:
            new_prices[trade] = result
        else:
            failures.append(trade)
            # Keep old prices for failed trades
            if trade in old_prices:
                new_prices[trade] = old_prices[trade]

    # Write new prices
    PRICES_FILE.write_text(json.dumps(new_prices, indent=2))
    print(f"\n✓ Saved {PRICES_FILE} ({PRICES_FILE.stat().st_size // 1024}KB)")

    # Compute diff
    changes = compute_diff(old_prices, new_prices)
    print(f"\n📊 {len(changes)} significant changes (>3%):")
    for c in changes[:20]:
        print(c)
    if len(changes) > 20:
        print(f"  ... and {len(changes)-20} more")

    if failures:
        print(f"\n⚠ Failed trades (kept old prices): {', '.join(failures)}")

    # Send notification
    if changes or failures:
        send_email_notification(changes)

    print(f"\n✓ Done.\n")


if __name__ == "__main__":
    main()
