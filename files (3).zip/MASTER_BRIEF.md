# 🎯 BuildCalc Pro — MASTER BRIEF for Chat Continuation

> **PROPÓSITO:** Pegar este archivo COMPLETO al inicio de un chat nuevo con Claude
> para retomar el proyecto sin perder tiempo. Incluye TODO el contexto necesario.

**Fecha última actualización:** 2026-05-17
**Estado:** Sesión 1 en progreso — preparando deploy + Payment Link

---

## 👤 Sobre el Owner (GP)

- **Nombre:** Gil Pesantez (GP)
- **Email:** gptradingclub@gmail.com
- **Ubicación:** Groton, CT (USA)
- **Idioma:** Spanish (informal, casual), código y UI en English
- **Otro negocio activo:** GP Trading Club (gptradingclub.com) — Flask app en DigitalOcean
- **Computadora:** Windows
- **Acceso al server:** Consola web de DigitalOcean (no SSH directo)

---

## 🏗️ Sobre BuildCalc Pro

### Concepto
**SaaS para contractors** — estimador profesional de construcción.
12 trades profesionales con specs detallados, AI live market price check,
regional pricing multipliers, PDF export.

### Domain
- **buildcalcpro.club** comprado en Namecheap (expira May 17, 2027)
- DNS configurado: 2 A Records (@ y www) → `178.128.148.13`

### Server
- DigitalOcean droplet: `178.128.148.13`
- Hostname: `ubuntu-s-1vcpu-1gb-nyc1`
- Acceso: root via DigitalOcean web console
- Nginx con sitio activo: `gptradingclub` (no tocar)
- Carpeta creada para BuildCalc: `/var/www/buildcalcpro/` (vacía aún)
- Backup hecho de config Nginx: `/etc/nginx.backup-YYYYMMDD/`

### Stripe
- Cuenta YA existe (la del trading club)
- Precio decidido: **$29/mes** (volumen play)
- Estrategia: 2 planes futuros — Pro $49 + Business $99

---

## 📦 Estado actual de los archivos

Los archivos existen en `/mnt/user-data/outputs/` (en este chat actual):

1. **`buildcalc-pro.jsx`** — React component completo (344 KB, 1314 líneas)
   - 12 trades profesionales (9-12 specs c/u)
   - Regional pricing (8 USA regions)
   - AI Live Market Check via Anthropic API
   - PDF generator con jsPDF
   - Theme: dark + orange (#f97316)
   - Fonts: Syne (headers) + Space Grotesk (numbers) + DM Mono (body)

2. **`buildcalc-pro.html`** — Standalone HTML version (347 KB)
   - Mismo código pero embebido con React via CDN
   - Listo para servir desde Nginx
   - Babel-standalone compila JSX en el browser

3. **`nginx-buildcalcpro.conf`** — Nginx server block
   - Para `buildcalcpro.club` + `www.buildcalcpro.club`
   - Sirve archivos estáticos desde `/var/www/buildcalcpro/`
   - Incluye gzip, cache headers, security headers

4. **`refresh_prices.py`** — Cron script
   - Mensual: usa Claude AI con web_search para actualizar precios
   - Output: `prices.json`
   - Notifica por email cambios >3%

5. **`DEPLOY.md`** — Guía paso a paso de deploy

**⚠️ IMPORTANTE:** En un chat nuevo, estos archivos NO estarán disponibles.
GP debe re-subirlos al chat nuevo, O pegar este brief y pedirle a Claude
que los regenere (lo cual funciona pero toma tiempo).

---

## ✅ Lo que ya está hecho

- [x] App completa con 12 trades profesionales (Roofing, Flooring, Drywall, Painting,
      Concrete, Framing, Plumbing, Electrical, HVAC, Siding, Trim, Cabinets)
- [x] Regional pricing system (8 regiones USA)
- [x] HTML standalone generado
- [x] Domain comprado: buildcalcpro.club
- [x] DNS configurado (2 A Records → 178.128.148.13)
- [x] Backup de Nginx hecho
- [x] Carpeta `/var/www/buildcalcpro/` creada en server
- [x] Repo GitHub iniciado (pero NO subido el archivo aún)

## ⏳ Lo que falta en SESIÓN 1 (vender HOY)

- [ ] Subir `buildcalc-pro.html` a GitHub
- [ ] Descargar desde server con `wget` a `/var/www/buildcalcpro/index.html`
- [ ] Activar Nginx config para buildcalcpro.club
- [ ] HTTPS con Let's Encrypt
- [ ] Verificar que `gptradingclub.com` sigue funcionando
- [ ] Crear LANDING PAGE de marketing (Hero, Features, Pricing, CTA)
- [ ] Crear Stripe Payment Link ($29/mo)
- [ ] Conectar CTA → Stripe Payment Link

## ⏳ Lo que falta en SESIÓN 2 (automatizar)

- [ ] Backend Flask con SQLite database
- [ ] Login/Register system
- [ ] Stripe Checkout integration (reemplazar Payment Link)
- [ ] Webhook de Stripe para auto-activación/cancelación
- [ ] Protección de rutas (no access sin paid sub)
- [ ] Admin dashboard

---

## 🎨 Diseño y branding

- **Brand name:** BUILDCALC PRO
- **Tagline:** "AI-Powered Estimator"
- **Owner credit:** "by Gil Pesantez"
- **Color primario:** Orange `#f97316`
- **Background:** Dark `#0a0c12`
- **Text:** `#e2ddd6`
- **Fonts:**
  - Headers (cortos, UPPERCASE): Syne, weight 900
  - Números grandes: Space Grotesk, weight 700
  - Body, monospace UI: DM Mono

---

## 📝 Preferencias técnicas de GP

- ✅ Casual/informal Spanish con typos OK
- ✅ Prefiere opciones binarias (A/B) sobre preguntas abiertas
- ✅ Quiere entender CADA paso técnico antes de ejecutarlo
- ✅ Profesional contractor language (Azek, Boral, KraftMaid, SW Emerald, etc.)
- ✅ NO le gusta el J-channel/F-channel en siding (no agrega plata)
- ✅ SÍ quiere Azek/Boral PVC trim (premium upsell)
- ❌ NO quiere romper su Trading Club bot
- ❌ NO le gusta hacer build steps complicados (por eso HTML standalone)

---

## 🚀 Comandos importantes ejecutados en server

```bash
# Backup hecho:
sudo cp -r /etc/nginx /etc/nginx.backup-$(date +%Y%m%d)

# Carpeta creada:
sudo mkdir -p /var/www/buildcalcpro

# Sites activos (solo gptradingclub):
ls /etc/nginx/sites-enabled/
# Output: gptradingclub
```

---

## 🎯 Plan estratégico de venta

### Sesión 1 (HOY) — "Make Money Mode"
**Goal:** Estar vendiendo HOY mismo, aunque sea manual.

1. App live en buildcalcpro.club
2. Landing page con CTA "Get Started — $29/mo"
3. CTA → Stripe Payment Link
4. Cliente paga → Stripe email automático con link a app
5. Tú recibes email cada venta

### Sesión 2 — "Make it Automatic"
**Goal:** Sin trabajo manual.

1. Backend Flask + SQLite
2. Login/Register
3. Stripe Checkout integrado (no link manual)
4. Webhook auto-activate/deactivate
5. Admin dashboard

### Sesión 3+ — Growth
1. Twitter/Instagram outreach a contractor influencers
2. Affiliate program (40% commission)
3. Multi-trade combos (full remodel)
4. Mobile app

---

## 💡 Decisiones de negocio tomadas

- **Precio:** $29/mo (volumen, no premium)
- **Target market:** Independent contractors USA
- **Diferenciador:** AI Live Market Check + Regional Pricing + 12 trades profesionales
- **Competencia:** Buildertrend ($99), JobTread ($129), Houzz Pro ($85) — todos más caros y complicados
- **Friends-of-GP:** Ya hay contractors esperando para probar

---

## 🔑 INSTRUCCIONES PARA CLAUDE EN CHAT NUEVO

Si ves este brief al inicio de un chat:

1. **Acknowledge** que recibiste el contexto completo
2. **NO repreguntes** cosas ya decididas (precio, domain, branding, server IP, etc.)
3. **Resume** brevemente dónde quedamos según la sección "Lo que falta"
4. **Pregunta** específicamente qué sesión quiere continuar (1 o 2)
5. Si necesitas regenerar archivos (`buildcalc-pro.html`, etc.), avisa que toma
   tiempo y propón hacerlo solo si es necesario
6. Recuerda: GP es contractor + trader, NO developer profesional —
   explica cada paso técnico

---

## 📞 Si Claude no encuentra los archivos

Pedirle a Claude:
> "Necesito que regeneres `buildcalc-pro.jsx` y `buildcalc-pro.html` basándote
> en este brief. El componente tiene 12 trades profesionales con specs como:
> Roofing (9 specs con chimneys/ridge vent/gutters/slate/cedar), Flooring (9 specs
> con patterns Herringbone/Versailles), Drywall (10 specs con popcorn removal),
> Painting (11 specs con stairs/cabinets), Concrete (10 specs con excavation/color),
> Framing (11 specs con Full House Frame option), Plumbing (10 specs con whole-house
> repipe), Electrical (11 specs con EV charger/generator), HVAC (10 specs con
> tonnage/SEER), Siding (11 specs con Azek/Boral trim, NO J-channel), Trim (10 specs
> con wainscoting/coffered), Cabinets (12 specs con countertops/backsplash)."

---

**Última cosa importante:** Si Claude pierde contexto en medio de Sesión 1 o 2,
GP debe pegar este brief Y mencionar exactamente en qué paso está atascado.
