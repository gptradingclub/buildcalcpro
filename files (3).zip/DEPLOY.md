# 🚀 BuildCalc Pro — Guía de Deploy a buildcalcpro.club

**Para:** GP (Gil Pesantez)
**Servidor:** Tu DigitalOcean droplet existente (donde corre gptradingclub.com)
**Dominio:** buildcalcpro.club (en Namecheap)
**Tiempo total:** ~30-45 minutos

---

## ⚠️ ANTES DE EMPEZAR

Asegúrate de tener:
- [ ] La IP de tu servidor DigitalOcean (la encuentras en el dashboard de DigitalOcean)
- [ ] Tu usuario SSH (probablemente `root` o `gp` o similar)
- [ ] Tu contraseña SSH o tu SSH key
- [ ] Acceso a Namecheap (donde compraste buildcalcpro.club)

Si no tienes alguno, dime y te ayudo a recuperarlo.

---

## PARTE 1: Conectarse al servidor por SSH

### 1.1 Encontrar la IP de tu droplet
1. Entra a https://cloud.digitalocean.com/
2. Click en "Droplets" en el sidebar
3. Verás tu droplet listado — copia la **IP address** (ejemplo: `143.198.45.67`)

### 1.2 Conectarse desde tu Mac/PC

**Si estás en Mac o Linux:**
Abre la Terminal (Cmd+Space → "Terminal") y escribe:
```bash
ssh root@TU_IP_AQUI
```
Por ejemplo: `ssh root@143.198.45.67`

Si te pide contraseña, la metes (no se ve mientras escribes — es normal).

**Si estás en Windows:**
Opción A — Usa Windows Terminal o PowerShell:
```powershell
ssh root@TU_IP_AQUI
```

Opción B — Usa PuTTY (si lo tienes instalado):
- Host name: `TU_IP_AQUI`
- Port: `22`
- Connection type: SSH
- Click "Open"

**Si no funciona o no sabes la contraseña:**
- Ve al dashboard de DigitalOcean
- Click en tu droplet → "Access" → "Launch Droplet Console"
- Esto te abre una terminal en el navegador

### 1.3 Verificar que estás conectado
Una vez conectado verás algo así:
```
root@buildcalc-droplet:~#
```
**¡Estás dentro del servidor!** ✅

---

## PARTE 2: Verificar que tu Nginx ya está corriendo

Esto es solo para confirmar que no vamos a romper gptradingclub.com:

```bash
sudo systemctl status nginx
```

Deberías ver `active (running)` en verde. Presiona `q` para salir.

Lista los sitios que ya tienes:
```bash
ls /etc/nginx/sites-enabled/
```

Deberías ver algo como `gptradingclub` o similar. **NO BORRES NADA**.

---

## PARTE 3: Configurar DNS en Namecheap

**HACER ESTO PRIMERO** porque la propagación DNS toma tiempo (5-30 min).

1. Entra a https://www.namecheap.com/ y haz login
2. Dashboard → "Domain List" → busca `buildcalcpro.club` → Click "Manage"
3. Click en la pestaña **"Advanced DNS"**
4. **Borra cualquier record que diga "URL Redirect"** (puede haber uno por defecto)
5. Click en **"Add New Record"** y agrega:

| Type | Host | Value | TTL |
|------|------|-------|-----|
| A Record | `@` | `TU_IP_DE_DIGITALOCEAN` | 5 min |
| A Record | `www` | `TU_IP_DE_DIGITALOCEAN` | 5 min |

6. Click el ícono ✓ (check verde) para guardar cada record

**Listo el DNS.** Mientras propaga, seguimos con el servidor.

---

## PARTE 4: Subir los archivos al servidor

Tienes 2 archivos para subir:
- `buildcalc-pro.html` (la app)
- `nginx-buildcalcpro.conf` (la config de Nginx)

### Opción A: Si estás en tu Mac/PC con SCP (más fácil)

Abre OTRA terminal (deja la SSH abierta) y desde tu carpeta de Downloads:

```bash
# Cambia TU_IP por la IP real
scp buildcalc-pro.html root@TU_IP:/tmp/
scp nginx-buildcalcpro.conf root@TU_IP:/tmp/
```

### Opción B: Si estás usando la consola web de DigitalOcean

Necesitas pegar el contenido directamente. Te muestro cómo más adelante.

### Verificar que llegaron
En tu sesión SSH original, ejecuta:
```bash
ls -la /tmp/buildcalc-pro.html /tmp/nginx-buildcalcpro.conf
```

Deberías ver ambos archivos listados.

---

## PARTE 5: Crear el directorio y mover los archivos

En tu sesión SSH (root@buildcalc-droplet:~#):

```bash
# Crear el directorio para la app
sudo mkdir -p /var/www/buildcalcpro

# Mover el HTML a su lugar y renombrarlo index.html
sudo mv /tmp/buildcalc-pro.html /var/www/buildcalcpro/index.html

# Dar permisos correctos
sudo chown -R www-data:www-data /var/www/buildcalcpro
sudo chmod -R 755 /var/www/buildcalcpro

# Verificar
ls -la /var/www/buildcalcpro/
```

Deberías ver `index.html` listado con dueño `www-data`.

---

## PARTE 6: Activar la config de Nginx

```bash
# Copiar la config a sites-available
sudo mv /tmp/nginx-buildcalcpro.conf /etc/nginx/sites-available/buildcalcpro

# Crear el symlink en sites-enabled para activarla
sudo ln -s /etc/nginx/sites-available/buildcalcpro /etc/nginx/sites-enabled/buildcalcpro

# Verificar que Nginx esté contento con la nueva config
sudo nginx -t
```

**Si ves `syntax is ok` y `test is successful`:** ✅ Sigue al próximo paso.

**Si ves errores:** PARA. Cópiame el error completo y te ayudo.

```bash
# Recargar Nginx (esto NO interrumpe gptradingclub.com)
sudo systemctl reload nginx
```

---

## PARTE 7: Verificar que funciona (HTTP por ahora)

### 7.1 Verificar DNS
```bash
ping -c 3 buildcalcpro.club
```

Debes ver respuestas desde tu IP de DigitalOcean. Si dice "unknown host" o muestra otra IP, el DNS no propagó todavía — espera 10 min más.

### 7.2 Probar el sitio
En tu navegador:
```
http://buildcalcpro.club
```

(Nota: HTTP, no HTTPS aún — eso lo agregamos en el siguiente paso)

Deberías ver **BUILDCALC PRO** cargar. 🎉

Si ves errores 404 o nada carga, revisa:
```bash
sudo tail -20 /var/log/nginx/buildcalcpro_error.log
```

---

## PARTE 8: Agregar SSL (HTTPS) con Let's Encrypt

```bash
# Verificar si tienes certbot instalado
which certbot
```

**Si no está instalado:**
```bash
sudo apt update
sudo apt install certbot python3-certbot-nginx -y
```

**Obtener el certificado SSL:**
```bash
sudo certbot --nginx -d buildcalcpro.club -d www.buildcalcpro.club
```

Te va a preguntar:
1. **Email** → poné tu email (`gptradingclub@gmail.com`)
2. **Aceptar términos** → `Y`
3. **Compartir email con EFF** → `N` (opcional)
4. **¿Redirigir HTTP a HTTPS?** → `2` (sí, redirige)

**Listo!** Ahora https://buildcalcpro.club funciona con candadito verde. 🔒

El certificado se auto-renueva cada 90 días, no tienes que hacer nada.

---

## PARTE 9: (OPCIONAL) Cron job para auto-refresh de precios

Esto es para que los precios se actualicen automáticamente cada mes con AI:

### 9.1 Subir el script
```bash
# Desde tu Mac/PC:
scp refresh_prices.py root@TU_IP:/var/www/buildcalcpro/
```

### 9.2 Instalar dependencias
```bash
# En el servidor:
sudo apt install python3-pip -y
pip3 install anthropic --break-system-packages
```

### 9.3 Configurar variables de entorno
```bash
# Editar bashrc para que estén disponibles siempre
nano ~/.bashrc
```

Al final del archivo, agrega:
```bash
export ANTHROPIC_API_KEY=sk-ant-tu-api-key-aqui
export NOTIFY_EMAIL=gptradingclub@gmail.com
export SMTP_USER=gptradingclub@gmail.com
export SMTP_PASS=tu-gmail-app-password
```

Guardar con `Ctrl+O`, `Enter`, `Ctrl+X`.

Recargar:
```bash
source ~/.bashrc
```

### 9.4 Crear el cron job
```bash
crontab -e
```

Si te pregunta editor, elige `1` (nano).

Al final agrega esta línea:
```
0 4 1 * * cd /var/www/buildcalcpro && /usr/bin/python3 refresh_prices.py >> refresh.log 2>&1
```

Guardar con `Ctrl+O`, `Enter`, `Ctrl+X`.

Esto corre el 1ro de cada mes a las 4 AM, busca precios actualizados con AI, y te manda email con los cambios.

### 9.5 Probar el script manualmente
```bash
cd /var/www/buildcalcpro
python3 refresh_prices.py
```

Debe mostrar progreso por cada trade. Si funciona, ¡estás listo!

---

## ✅ CHECKLIST FINAL

- [ ] DNS configurado en Namecheap (A records para `@` y `www`)
- [ ] `/var/www/buildcalcpro/index.html` existe
- [ ] Nginx config en `/etc/nginx/sites-enabled/buildcalcpro`
- [ ] `sudo nginx -t` no da errores
- [ ] http://buildcalcpro.club carga la app
- [ ] https://buildcalcpro.club tiene candadito verde
- [ ] gptradingclub.com sigue funcionando (no rompimos nada)

---

## 🆘 Troubleshooting común

**Problema:** "502 Bad Gateway" o "Welcome to nginx" al abrir el dominio
→ La config no está activada. Verifica: `ls /etc/nginx/sites-enabled/buildcalcpro`

**Problema:** Browser dice "Site can't be reached"
→ DNS no propagó. Espera 10-15 min más, o verifica en https://dnschecker.org

**Problema:** Certbot falla con "DNS problem"
→ El DNS aún no apunta a tu IP. Espera más, después corre certbot de nuevo.

**Problema:** "Permission denied" al hacer scp
→ Asegúrate de usar `root` u otro usuario con sudo. Tal vez necesitas tu SSH key.

**Problema:** No puedo conectar por SSH
→ Verifica la IP correcta, y que tu IP de casa no esté bloqueada en el firewall de DigitalOcean.

---

## 📞 ¿Atascado? 

Volve al chat y dime:
1. En qué paso estás
2. El error exacto que viste (copy-paste)
3. Cualquier output que recibiste

Te ayudo en el momento.

🎉 ¡Buena suerte con el deploy GP!
